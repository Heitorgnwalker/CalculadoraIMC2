package com.example.calculadoraimc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AbaixoDoPesoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abaixo_do_peso2);

        TextView txtDicas = findViewById(R.id.txtDicas);
        txtDicas.setText(getDicasAbaixoDoPeso());

        Button btnFechar = findViewById(R.id.btnFechar);
        btnFechar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private String getDicasAbaixoDoPeso() {
        return "Aqui estão algumas dicas para ganhar peso de forma saudável:\n\n" +
                "1. **Aumente a ingestão calórica**: Inclua alimentos ricos em calorias, como nozes, abacate, azeite de oliva e sementes em suas refeições.\n\n" +
                "2. **Consuma refeições mais frequentes**: Em vez de fazer apenas 3 refeições grandes, tente comer várias pequenas refeições ao longo do dia.\n\n" +
                "3. **Coma proteínas suficientes**: Alimentos ricos em proteínas como ovos, carne, peixe, laticínios, feijão e leguminosas ajudam a ganhar massa muscular.\n\n" +
                "4. **Aposte nos carboidratos saudáveis**: Arroz integral, batata-doce e quinoa são ótimas fontes de carboidratos para ganhar peso com saúde.\n\n" +
                "5. **Evite calorias vazias**: Evite junk food, que pode causar inflamações no corpo, e prefira alimentos naturais e nutritivos.\n\n" +
                "6. **Inclua shakes e smoothies nutritivos**: Beba shakes com frutas, aveia e proteína em pó entre as refeições.\n\n" +
                "7. **Exercícios de força**: Pratique musculação para ganhar massa muscular em vez de apenas gordura.\n\n" +
                "8. **Descanse adequadamente**: Dormir bem é essencial para a recuperação muscular e o ganho de peso saudável.";
    }
}
